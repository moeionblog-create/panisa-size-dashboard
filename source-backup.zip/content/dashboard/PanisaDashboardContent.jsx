import React, { useMemo } from "react";
import { DataComponent, DataTable, EvidenceChart, Filters, MetricCard, SectionHeader,
  SortableItem, SortableRegion, useDataApp } from "../../data-app-public.jsx";
import "./panisa-statistics.css";
import { ChestSizeStatistics } from './ChestSizeStatistics.jsx';
import { ShirtSizeMatrix } from './ShirtSizeMatrix.jsx';

const QUERY = "measurement_pairs";
const formatNumber = value => new Intl.NumberFormat("th-TH", { maximumFractionDigits: 1 }).format(value);
const formatDate = value => new Intl.DateTimeFormat("th-TH", { day:"numeric", month:"short", year:"numeric" }).format(new Date(value + "T12:00:00+07:00"));
const gapSpec = { type:"horizontalBar", x:"gapLabel", y:"conversations", xLabel:"จำนวนแชท",
  yLabel:"สะโพก − เอว (นิ้ว)", showXAxisLabel:true, showYAxisLabel:true, showValues:true, valueDecimals:0, startAtZero:true, stackable:false };

export function calculateMeasurements(rows) {
  const gaps = new Map();
  const pairs = new Map();
  for (const row of rows) {
    gaps.set(row.gap, (gaps.get(row.gap) ?? 0) + 1);
    const key = `${row.waist}/${row.hip}`;
    const current = pairs.get(key) ?? { waist:row.waist, hip:row.hip, gap:row.gap, conversations:0 };
    current.conversations += 1;
    pairs.set(key, current);
  }
  const sorted = [...rows].map(row => row.gap).sort((a,b) => a-b);
  const n = rows.length;
  const maxCount = n ? Math.max(...gaps.values()) : null;
  const modes = [...gaps].filter(([,count]) => count === maxCount).map(([gap]) => gap).sort((a,b) => a-b);
  const inRange = rows.filter(row => row.gap >= 8 && row.gap <= 10).length;
  const median = !n ? null : n % 2 ? sorted[Math.floor(n/2)] : (sorted[n/2-1] + sorted[n/2])/2;
  return {
    n, modes, inRange, median, mean:n ? sorted.reduce((a,b)=>a+b,0)/n : null,
    share:n ? 100*inRange/n : null,
    explicitUnits:rows.filter(row => row.unitBasis === "ระบุหน่วยโดยตรง").length,
    distribution:[...gaps].sort((a,b)=>a[0]-b[0]).map(([gap,conversations]) => ({ gap, gapLabel:String(gap), conversations, percent:100*conversations/n })),
    frequentPairs:[...pairs.values()].sort((a,b)=>b.conversations-a.conversations || a.waist-b.waist || a.hip-b.hip).map(row => ({...row,percent:100*row.conversations/n})),
  };
}

export function DashboardContent() {
  const { snapshot, queries, filters, setFilter } = useDataApp();
  const original = queries[QUERY]?.rows ?? [];
  const rows = useMemo(() => original.filter(row => !filters.year || filters.year === "all" || row.year === filters.year), [original, filters.year]);
  const stats = useMemo(() => calculateMeasurements(rows), [rows]);
  const modeText = stats.modes.length ? stats.modes.map(formatNumber).join(" / ") + " นิ้ว" : "—";
  const scopeRows = { sourceRows:rows };
  const summaryRows = [{ conversations:stats.n, mode:stats.modes.join(" / "), rangeConversations:stats.inRange, rangePercent:stats.share, mean:stats.mean, median:stats.median }];
  const cutoff = snapshot.panisa?.archiveMeasurementThrough;
  const topPairs = stats.frequentPairs.slice(0,10);

  return <article className="panisa-statistics">
    <div className="panisa-statistics-links">
      <a href="https://moeionblog-create.github.io/photo-finder/">เปิดคลังภาพสินค้า ↗</a>
      <span>ชุดเอว–สะโพกเดิมถึง {cutoff ? formatDate(cutoff) : "—"} · ยังไม่อัปเดตจาก Facebook อัตโนมัติ</span>
    </div>
    <ShirtSizeMatrix />
    <Filters sticky filters={snapshot.filters} queries={queries} values={filters} onChange={setFilter}
      ariaLabel="เลือกปีของสัดส่วนลูกค้า" clearLabel="ดูทุกปี" />
    <ChestSizeStatistics />
    <p className="panisa-statistics-scope">ผลเบื้องต้นจากแชทที่มีคู่สัดส่วนชัดเจน หน่วยที่ไม่ระบุให้ตีความเป็นนิ้วตามบริบทของร้าน</p>

    <SortableRegion id="panisa:measurement-statistics" variant="canvas" spacing="standard" columns={12}
      rows={[
        { id:"panisa:headline", kind:"metrics", items:["panisa-chat-count","panisa-gap-mode","panisa-gap-share"] },
        { id:"panisa:distribution", items:["panisa-gap-distribution"], header:<SectionHeader id="panisa-distribution-heading" title="เอวกับสะโพกต่างกันเท่าไร" /> },
        { id:"panisa:pairs", items:["panisa-frequent-pairs"] },
      ]} label="สถิติสัดส่วนลูกค้า">
      <SortableItem id="panisa-chat-count" label="แชทที่คัดสัดส่วนได้" kind="metric" span={4}>
        <MetricCard id="panisa-chat-count" queryId={QUERY} title="แชทที่คัดสัดส่วนได้"
          value={formatNumber(stats.n)} description="นับหนึ่งคู่สัดส่วนต่อแชท ไม่ใช่จำนวนลูกค้าทั้งร้าน"
          {...scopeRows} displayRows={summaryRows} />
      </SortableItem>
      <SortableItem id="panisa-gap-mode" label="ส่วนต่างที่พบมากที่สุด" kind="metric" span={4}>
        <MetricCard id="panisa-gap-mode" queryId={QUERY} title="ส่วนต่างที่พบมากที่สุด"
          value={modeText} description="คำนวณจากสะโพก ลบ เอวของผู้สวม"
          {...scopeRows} displayRows={summaryRows} />
      </SortableItem>
      <SortableItem id="panisa-gap-share" label="ส่วนต่างอยู่ช่วง 8–10 นิ้ว" kind="metric" span={4}>
        <MetricCard id="panisa-gap-share" queryId={QUERY} title="ส่วนต่างอยู่ช่วง 8–10 นิ้ว"
          value={stats.share === null ? "—" : formatNumber(stats.share) + "%"}
          description={stats.n ? `${formatNumber(stats.inRange)} จาก ${formatNumber(stats.n)} แชทที่เลือกดู` : "ไม่มีข้อมูลในกลุ่มที่เลือก"}
          {...scopeRows} displayRows={summaryRows} />
      </SortableItem>

      <SortableItem id="panisa-gap-distribution" label="จำนวนแชทตามส่วนต่างสะโพกกับเอว" kind="chart" span={12}>
        <EvidenceChart id="panisa-gap-distribution" queryId={QUERY} variant="card"
          title="จำนวนแชทตามส่วนต่างสะโพกกับเอว" spec={gapSpec} rows={stats.distribution}
          {...scopeRows} height={Math.max(220, stats.distribution.length * 26 + 60)} description="หน่วยนิ้ว ตามค่าที่ผู้สวมแจ้งในแชท">
          <p className="panisa-chart-footnote" data-reviewed-rows>
            {stats.n ? `ค่าเฉลี่ย ${formatNumber(stats.mean)} นิ้ว · มัธยฐาน ${formatNumber(stats.median)} นิ้ว` : "ไม่มีคู่สัดส่วนตรงกับตัวกรองนี้"}
            {stats.n > 0 && stats.n < 30 ? " · กลุ่มนี้มีข้อมูลน้อย ใช้ดูเฉพาะรายการที่พบ" : ""}
          </p>
        </EvidenceChart>
      </SortableItem>

      <SortableItem id="panisa-frequent-pairs" label="คู่เอวและสะโพกที่พบบ่อย" kind="table" span={12}>
        <DataComponent id="panisa-frequent-pairs" queryId={QUERY} kind="table" variant="card"
          title="คู่เอวและสะโพกที่พบบ่อย" description="แสดงได้ถึง 10 คู่สัดส่วนที่พบมากที่สุดในกลุ่มที่เลือกดู"
          {...scopeRows} displayRows={topPairs}>
          <DataTable rows={topPairs} searchable={false} label="คู่เอวและสะโพกที่พบบ่อย" columns={[
            {field:"waist",label:"เอว (นิ้ว)"},{field:"hip",label:"สะโพก (นิ้ว)"},
            {field:"gap",label:"ส่วนต่าง (นิ้ว)"},{field:"conversations",label:"จำนวนแชท"},
            {field:"percent",label:"ร้อยละของกลุ่มที่เลือก",renderCell:value=>formatNumber(value)},
          ]} />
        </DataComponent>
      </SortableItem>
    </SortableRegion>

    <div className="panisa-statistics-data-note" data-reviewed-rows>
      <p>{formatNumber(stats.explicitUnits)} จาก {formatNumber(stats.n)} แชทในกลุ่มนี้ระบุหน่วยโดยตรง ที่เหลือตีความเป็นนิ้วจากบริบทของร้าน</p>
      <p>หน้าเพจนี้เก็บข้อมูลที่คัดแล้วไว้ในเครื่อง กราฟคำนวณด้วยโปรแกรมปกติ เมื่อนำข้อมูลชุดใหม่ที่ตรวจแล้วมาอัปเดต สถิติจะคำนวณใหม่ได้โดยไม่ต้องมี AI คอยวาดกราฟ</p>
    </div>
  </article>;
}
