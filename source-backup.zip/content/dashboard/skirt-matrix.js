export function skirtFit(rows, hip, waist) {
  const gap = hip - waist;
  const review = reason => ({gap, label:'ตรวจเพิ่ม', status:'review', reason, options:[]});
  if (!(hip > 0 && waist > 0) || gap < 1) return review('ส่วนต่างนี้ยังไม่มีกฎยืนยันจากร้าน ตรวจสัดส่วนก่อนแนะนำ');
  if ((gap >= 1 && gap <= 5) || gap >= 13) return {gap, label:'Custom', status:'custom', options:[], reason:gap >= 13 ? 'ส่วนต่างตั้งแต่ 13 นิ้ว: เสนอ custom เท่านั้น' : 'ส่วนต่าง 1–5 นิ้ว: เสนอ custom ทันที', reply:'สัดส่วนนี้แนะนำเป็นงาน custom ครับผม ขอเช็กรายละเอียดและค่าบริการให้ก่อนนะครับ'};
  if (!((gap >= 6 && gap <= 7) || (gap >= 8 && gap <= 10) || (gap >= 11 && gap <= 12))) return review('ส่วนต่างเป็นเศษนิ้วระหว่างช่วงที่ร้านกำหนด ต้องตรวจเพิ่มเติม');
  const sorted = [...rows].sort((a,b)=>a.waist-b.waist);
  const index = sorted.findIndex(r=>r.waist===waist);
  if (index < 0) {
    const lower = sorted.filter(r=>r.waist<waist).at(-1), upper=sorted.find(r=>r.waist>waist);
    if (!lower || !upper) return {...review('เอวอยู่นอกช่วงไซส์มาตรฐานของรุ่น ต้องตรวจเพิ่มเติม ไม่ขยับไซส์โดยเดา'),label:'ตรวจเอว',options:[lower,upper].filter(Boolean)};
    const compared=[lower,upper].map(r=>({...r,assessment:r.waist<waist && r.hip<hip?'เอวและสะโพกเล็กกว่าตัวจริง':r.waist<waist?'เอวเล็กกว่าตัวจริง':r.hip<hip?'สะโพกเล็กกว่าตัวจริง':`เอวหลวม ${r.waist-waist} / สะโพกหลวม ${r.hip-hip} นิ้ว`}));
    const candidate=[lower,upper].find(r=>r.waist>=waist && r.hip>=hip);
    if (!candidate) return {...review('เอวอยู่ระหว่างสองไซส์ แต่ไม่มีตัวเลือกข้างเคียงที่รับได้ทั้งเอวและสะโพก ต้องตรวจไซส์เพิ่มก่อนยืนยัน'),options:[lower,upper],compared};
    const loose=gap<=7;
    return {gap,label:candidate.size+(loose?'*':''),status:'size',options:[candidate],compared,
      reason:`เอวอยู่ระหว่าง ${lower.size} / ${upper.size} เทียบสะโพกแล้วเลือก ${candidate.size} ที่ไม่คับทั้งเอวและสะโพก`,
      reply:`แนะนำไซส์ ${candidate.size} ครับผม เอวกระโปรง ${candidate.waist} นิ้ว หลวม ${candidate.waist-waist} นิ้ว สะโพก ${candidate.hip} นิ้ว หลวม ${candidate.hip-hip} นิ้วครับ${loose?' ถ้ามีช่างประจำแถวบ้าน ให้ช่างเก็บสะโพกเข้าได้ครับ':''}`};
  }
  const row=sorted[index+(gap>=11?1:0)];
  if (!row) return review('กฎให้เพิ่ม 1 ไซส์จากไซส์เอวพอดี แต่เกินไซส์สูงสุดของรุ่น ต้องตรวจเพิ่มเติม');
  if (row.hip < hip) return {...review('ไซส์ตามกฎมีสะโพกเล็กกว่าตัวจริง ต้องตรวจเพิ่มเติมก่อนยืนยันว่าใส่ได้'),label:row.size+'!',options:[row]};
  const loose=gap<=7;
  return {gap,label:row.size+(loose?'*':''),status:'size',options:[row],reason:loose?'ยึดเอวพอดี แจ้งสะโพกหลวม ไม่เสนอ custom ก่อน':gap>=11?'หาไซส์เอวพอดี แล้วเพิ่ม 1 ไซส์ตามกฎร้าน':'เลือกไซส์เอวพอดีตามกฎส่วนต่าง 8–10 นิ้ว',reply:`แนะนำไซส์ ${row.size} ครับผม เอวกระโปรง ${row.waist} นิ้ว สะโพก ${row.hip} นิ้ว${loose?` สะโพกจะหลวม ${row.hip-hip} นิ้วครับ ถ้ามีช่างประจำแถวบ้าน ให้ช่างเก็บสะโพกเข้าได้ครับ`:gap>=11?` ไซส์นี้ขยับขึ้นหนึ่งไซส์เพื่อรับสะโพก เอวจะหลวม ${row.waist-waist} นิ้วครับ`:''}`};
}
