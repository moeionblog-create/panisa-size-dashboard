export const skirtSizeLabel = size => size === 'XXL' ? '2XL' : size;

export function skirtFit(rows, hip, waist, customPlans = {}, customPolicy = {}) {
  const gap = hip - waist;
  if (gap >= 13) {
    return {gap, label:'', status:'blank', reason:'', options:[]};
  }
  if (!Number.isFinite(hip) || !Number.isFinite(waist) || hip <= 0 || waist <= 0 || !rows.length) {
    return {gap, label:'ตรวจเพิ่ม', status:'review', reason:'ไม่มีขนาดที่ใช้เทียบได้ กรุณาตรวจข้อมูล', options:[]};
  }
  const candidate = [...rows].sort((a,b)=>a.waist-b.waist).find(r =>
    r.waist >= waist && r.waist - waist <= 1 && r.hip >= hip && r.hip - hip <= 2);
  if (candidate) {
    const waistEase = candidate.waist - waist, hipEase = candidate.hip - hip;
    const warning = hipEase === 2 ? ' ต้องแจ้งลูกค้าว่าสะโพกหลวม 2 นิ้ว' : '';
    return {gap, label:skirtSizeLabel(candidate.size)+(hipEase===2?'*':''), status:'size', options:[candidate],
      reason:`เอวหลวม ${waistEase} นิ้ว / สะโพกหลวม ${hipEase} นิ้ว${warning}`,
      reply:candidate.size==='XS' && hipEase===2
        ? 'แนะนำไซส์ XS ครับ สะโพกจะหลวมสองนิ้วนะครับ ถ้าสวมแล้วหลวม ให้ช่างแถวบ้านปรับเข้าให้ได้นะครับ หรือหากให้ร้านปรับให้ ฟรีได้ครับ แต่หากให้ร้านปรับแล้วจะไม่สามารถเปลี่ยนสินค้าได้ครับผม'
        : `แนะนำไซส์ ${skirtSizeLabel(candidate.size)} ค่ะ เอวกระโปรง ${candidate.waist} นิ้ว สะโพก ${candidate.hip} นิ้ว เอวหลวม ${waistEase} นิ้ว และสะโพกหลวม ${hipEase} นิ้วค่ะ`};
  }
  const plans = (customPlans[`${waist}/${hip}`] ?? []).flatMap(plan => {
    const base = rows.find(r=>skirtSizeLabel(r.size)===plan.size);
    if (!base) return [];
    const adjustments = [['เอว',base.waist,plan.waist],['สะโพก',base.hip,plan.hip]]
      .filter(([,from,to])=>from!==to).map(([part,from,to])=>`${to>from?'ขยาย':'ลด'}${part} ${Math.abs(to-from)} นิ้ว (${from} → ${to})`);
    return [{...plan, instruction:`${plan.size} ${adjustments.join(' / ')}`,
      ease:`เอวหลวม ${plan.waist-waist} นิ้ว / สะโพกหลวม ${plan.hip-hip} นิ้ว`,
      warning:plan.hip-hip===2?'ต้องแจ้งลูกค้าว่าสะโพกหลวม 2 นิ้ว':''}];
  });
  return {gap, label:'C', status:'custom', options:[], plans, customFee:customPolicy.fee,
    reason:'Custom — ไม่มีไซส์ปกติที่เอวหลวม 0–1 นิ้ว และสะโพกหลวม 0–2 นิ้วพร้อมกัน',
    reply:customPolicy.customerReply ?? 'สัดส่วนนี้จะเป็น Custom นะครับ'};
}
