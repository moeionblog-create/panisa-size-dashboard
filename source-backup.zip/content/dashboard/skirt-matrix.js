export function skirtFit(rows, hip, waist) {
  const gap = hip - waist;
  const review = reason => ({gap, label:'ตรวจเพิ่ม', status:'review', reason, options:[]});
  if (!(hip > 0 && waist > 0) || gap < 1) return review('ส่วนต่างนี้ยังไม่มีกฎยืนยันจากร้าน ตรวจสัดส่วนก่อนแนะนำ');
  if ((gap >= 1 && gap <= 5) || gap >= 13) return {gap, label:'Custom', status:'custom', options:[], reason:gap >= 13 ? 'ส่วนต่างตั้งแต่ 13 นิ้ว: เสนอ custom เท่านั้น' : 'ส่วนต่าง 1–5 นิ้ว: เสนอ custom ทันที', reply:'สัดส่วนนี้แนะนำเป็นงาน custom ครับผม ขอเช็กรายละเอียดและค่าบริการให้ก่อนนะครับ'};
  if (!((gap >= 6 && gap <= 7) || (gap >= 8 && gap <= 10) || (gap >= 11 && gap <= 12))) return review('ส่วนต่างเป็นเศษนิ้วระหว่างช่วงที่ร้านกำหนด ต้องตรวจเพิ่มเติม');
  const sorted = [...rows].sort((a,b)=>a.waist-b.waist);
  const index = sorted.findIndex(r=>r.waist===waist);
  if (index < 0) {
    const lower = sorted.filter(r=>r.waist<waist).at(-1), upper=sorted.find(r=>r.waist>waist);
    return {...review('ไม่มีไซส์เอวเท่าตัวจริง ตารางแสดงขนาดข้างเคียงให้ร้านตรวจ ยังไม่เลือกขึ้นหรือลงอัตโนมัติ'),label:'ตรวจเอว',options:[lower,upper].filter(Boolean)};
  }
  const row=sorted[index+(gap>=11?1:0)];
  if (!row) return review('กฎให้เพิ่ม 1 ไซส์จากไซส์เอวพอดี แต่เกินไซส์สูงสุดของรุ่น ต้องตรวจเพิ่มเติม');
  if (row.hip < hip) return {...review('ไซส์ตามกฎมีสะโพกเล็กกว่าตัวจริง ต้องตรวจเพิ่มเติมก่อนยืนยันว่าใส่ได้'),label:row.size+'!',options:[row]};
  const loose=gap<=7;
  return {gap,label:row.size+(loose?'*':''),status:'size',options:[row],reason:loose?'ยึดเอวพอดี แจ้งสะโพกหลวม ไม่เสนอ custom ก่อน':gap>=11?'หาไซส์เอวพอดี แล้วเพิ่ม 1 ไซส์ตามกฎร้าน':'เลือกไซส์เอวพอดีตามกฎส่วนต่าง 8–10 นิ้ว',reply:`แนะนำไซส์ ${row.size} ครับผม เอวกระโปรง ${row.waist} นิ้ว สะโพก ${row.hip} นิ้ว${loose?` สะโพกจะหลวม ${row.hip-hip} นิ้วครับ ถ้ามีช่างประจำแถวบ้าน ให้ช่างเก็บสะโพกเข้าได้ครับ`:gap>=11?` ไซส์นี้ขยับขึ้นหนึ่งไซส์เพื่อรับสะโพก เอวจะหลวม ${row.waist-waist} นิ้วครับ`:''}`};
}
