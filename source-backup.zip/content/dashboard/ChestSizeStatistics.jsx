import React from 'react';
import {DataComponent, DataTable, EvidenceChart, MetricCard, SectionHeader, useDataApp} from '../../data-app-public.jsx';

const fmt=n=>new Intl.NumberFormat('th-TH',{maximumFractionDigits:2}).format(n);
const order=['XS','S','M','L','XL','XXL','3XL','4XL','5XL'];
export function ChestSizeStatistics(){
  const {queries,filters}=useDataApp();
  const scope=key=>(queries[key]?.rows??[]).filter(r=>!filters.year||filters.year==='all'||r.year===filters.year);
  const pairs=scope('chest_waist_screened'), sizes=scope('shirt_size_statements'), coverage=scope('archive_coverage');
  const groups=new Map(), pairCounts=new Map();
  for(const r of pairs){ groups.set(r.gap,(groups.get(r.gap)??0)+1); const k=`${r.chest}/${r.waist}`; const p=pairCounts.get(k)??{chest:r.chest,waist:r.waist,conversations:0};p.conversations++;pairCounts.set(k,p); }
  const gapRows=[...groups].sort((a,b)=>a[0]-b[0]).map(([gap,conversations])=>({label:String(gap),conversations}));
  const average=pairs.length?pairs.reduce((n,r)=>n+r.gap,0)/pairs.length:null;
  const stages=['ร้านแนะนำ','ลูกค้าระบุเลือก','ลูกค้าขอเปลี่ยน'];
  const spec={type:'horizontalBar',x:'label',y:'conversations',xLabel:'จำนวนแชทตามหมวด',showValues:true,startAtZero:true,valueDecimals:0,stackable:false};
  return <section aria-label="อกเอวและไซส์เสื้อย้อนหลังสามปี">
    <SectionHeader id="three-year-heading" title="อก–เอว และไซส์เสื้อจากแชทย้อนหลัง"/>
    <p>ข้อมูล 13 ต.ค. 2023–5 ต.ค. 2026 · ช่วงปลายปี 2023 และปี 2026 ไม่เต็มปี · ไม่อัปเดตสด</p>
    <DataComponent id="archive-coverage" queryId="archive_coverage" kind="table" variant="card" title="ข้อมูลที่มีในแต่ละปี" sourceRows={coverage} displayRows={coverage} description="จำนวนรายการรวมข้อความ สื่อ และเหตุการณ์ แชทเดียวอาจอยู่หลายปี จึงบวกจำนวนแชทรายปีเป็นจำนวนลูกค้าไม่ได้">
      <DataTable rows={coverage} searchable={false} columns={[{field:'year',label:'ปี'},{field:'messages',label:'รายการที่นำเข้า'},{field:'conversations',label:'แชทที่มีข้อความในปีนั้น'}]}/>
    </DataComponent>
    <p><strong>อก–เอว: ผลคัดข้อความเบื้องต้น</strong> ใช้หนึ่งคู่ที่คงที่ต่อแชท ตัดช่วงตัวเลขและค่าที่ขัดกัน ยังไม่ได้อ่านบริบทครบทุกคู่ หน่วยที่ไม่ระบุตีความเป็นนิ้ว</p>
    <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:16}}>
      <MetricCard id="chest-pair-count" queryId="chest_waist_screened" title="แชทที่คัดคู่อก–เอวได้" value={fmt(pairs.length)} sourceRows={pairs} displayRows={[{count:pairs.length}]} description="ไม่ใช่จำนวนลูกค้าหรือคำสั่งซื้อทั้งหมด"/>
      <MetricCard id="chest-gap-mean" queryId="chest_waist_screened" title="อก − เอว เฉลี่ย" value={average===null?'—':`${fmt(average)} นิ้ว`} sourceRows={pairs} displayRows={[{mean:average}]} description="คำนวณเฉพาะคู่ตัวเลขในกลุ่มที่เลือก"/>
    </div>
    <EvidenceChart id="chest-gap-chart" queryId="chest_waist_screened" variant="card" title="รอบอกมากกว่าเอวกี่นิ้ว" rows={gapRows} sourceRows={pairs} spec={spec} height={Math.max(240,gapRows.length*24+60)}/>
    <DataComponent id="chest-waist-top-pairs" queryId="chest_waist_screened" kind="table" variant="card" title="คู่รอบอก–เอวที่พบมาก" sourceRows={pairs} displayRows={[...pairCounts.values()].sort((a,b)=>b.conversations-a.conversations).slice(0,10)}>
      <DataTable rows={[...pairCounts.values()].sort((a,b)=>b.conversations-a.conversations).slice(0,10)} searchable={false} columns={[{field:'chest',label:'อก (นิ้ว)'},{field:'waist',label:'เอว (นิ้ว)'},{field:'conversations',label:'จำนวนแชท'}]}/>
    </DataComponent>
    <SectionHeader id="size-statement-heading" title="ไซส์เสื้อที่ปรากฏในแต่ละขั้นตอน"/>
    <p>นับแชทต่อปี / ขั้นตอน / ไซส์ ไม่ใช่จำนวนตัวที่ขายหรือไซส์สุดท้ายที่ชำระเงินแล้ว แชทเดียวอาจปรากฏหลายหมวด ข้อความเลือกและขอเปลี่ยนผ่านการตรวจข้อความที่คัดพบ ส่วนคำแนะนำร้านยังเป็นการคัดด้วยคำค้น</p>
    <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:16}}>
    {stages.map((stage,i)=>{const source=sizes.filter(r=>r.stage===stage);const rows=order.map(label=>({label,conversations:source.filter(r=>r.size===label).reduce((n,r)=>n+r.conversations,0)})).filter(r=>r.conversations);
      return <EvidenceChart key={stage} id={`shirt-stage-${i}`} queryId="shirt_size_statements" variant="card" title={stage} description={i===2?'ไซส์ปลายทางที่ขอเปลี่ยน ไม่ยืนยันว่าเปลี่ยนสำเร็จ':i===1?'ข้อความเลือกที่ชัดเจน ไม่รวมการตอบตกลงโดยไม่ระบุไซส์':'ไซส์ที่พบในคำแนะนำ ไม่เท่ากับไซส์ที่ซื้อ'} rows={rows} sourceRows={source} spec={spec} height={320}/>;})}
    </div>
    <p>ยังไม่จับคู่สัดส่วนกับไซส์ที่ซื้อเป็นสถิติ เพราะต้องยืนยันรุ่นสินค้า ผู้สวม และออเดอร์เดียวกันก่อน ภาพ เสียง และข้อความที่ไม่ระบุไซส์เสื้อชัดเจนยังไม่ถูกนับ</p>
    <hr/>
    <SectionHeader id="retained-hip-heading" title="เอว–สะโพก: สถิติเดิมที่ตรวจข้อความแล้ว"/>
  </section>;
}
