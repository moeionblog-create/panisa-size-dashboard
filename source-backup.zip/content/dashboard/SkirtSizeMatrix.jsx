import React,{useState} from 'react';
import {DataComponent,Dropdown,useDataApp} from '../../data-app-public.jsx';
import {skirtFit} from './skirt-matrix.js';
import './shirt-matrix.css';
const labels={artificial_silk_v1:'ไหมเทียม',woven_sets_v1:'ลูกแก้ว / ข้าวหลามตัด / เหลืองกนก / น้ำเงินขิด / ฟ้าบีต้า',galan_v1:'กาแลนด์'};
const hips=Array.from({length:23},(_,i)=>30+i), waists=Array.from({length:25},(_,i)=>22+i);
export function SkirtSizeMatrix(){
  const {queries}=useDataApp();
  const [model,setModel]=useState('artificial_silk_v1'),[point,setPoint]=useState({hip:35,waist:25});
  const rows=(queries.skirt_size_chart?.rows??[]).filter(r=>r.model===model);
  const charts=(queries.shirt_chart_images?.rows??[]).filter(r=>r.model===model);
  const fit=(h,w)=>skirtFit(rows,h,w), selected=fit(point.hip,point.waist);
  const displayRows=waists.flatMap(w=>hips.map(h=>{const f=fit(h,w);return {model:labels[model],bodyHip:h,bodyWaist:w,gap:f.gap,result:f.label,status:f.status,reason:f.reason};}));
  return <section className="shirt-matrix" id="skirt-size-matrix">
    <DataComponent id="panisa-skirt-matrix" queryId="skirt_size_chart" kind="table" variant="card" title="ตารางไขว้เลือกไซส์กระโปรง · สะโพก × เอว" sourceRows={rows} displayRows={displayRows}
      description="ขนาดกระโปรงจริงจากตารางทั้งสามกลุ่ม ตรวจ 16 ต.ค. 2026 · ใช้กฎส่วนต่างล่าสุดจากเจ้าของร้าน ไม่ใช่สถิติไซส์ที่ซื้อ"
      headerControls={<Dropdown label="รุ่นกระโปรง" showLabel choices={Object.keys(labels)} choiceLabels={labels} value={model} onChange={setModel}/>}>
      <p>แกน X = สะโพกตัวจริง · แกน Y = เอวตัวจริง · หน่วยนิ้ว · กดช่องเพื่อดูขนาดและแนวทางตอบลูกค้า</p>
      <p><span className="skirt-gap-ten-key" aria-hidden="true"/> ช่องสีทอง = สะโพกมากกว่าเอว 10 นิ้ว เช่น เอว 30 / สะโพก 40 · ไฮไลต์สัดส่วน ไม่ได้หมายความว่าทุกช่องใส่ได้</p>
      <p>เอวระหว่างสองไซส์: เทียบไซส์ข้างเคียง แล้วดูสะโพกตัดสิน โดยไม่เลือกตัวที่เอวหรือสะโพกคับ เช่น เอว 25 / สะโพก 35 → S · กรณีเข้าเกณฑ์ custom ยังใช้กฎเดิม</p>
      <details><summary>ดูกฎเลือกไซส์และตารางต้นฉบับ</summary>
        <p>ส่วนต่าง = สะโพกตัวจริง − เอวตัวจริง: 1–5 เสนอ custom · 6–7 ยึดเอวและแจ้งสะโพกหลวม · 8–10 เลือกเอวพอดี · 11–12 เลือกเอวพอดีแล้วเพิ่ม 1 ไซส์ · 13 ขึ้นไป custom เท่านั้น</p>
        <p>หลักทรงที่ร้านชอบคือสะโพกพอดีหรือหลวม 1 นิ้ว แต่ตารางนี้ใช้กฎแต่ละช่วงด้านบน จึงอาจมีระยะเผื่อมากกว่า 1 นิ้ว แสดงขนาดจริงทุกครั้ง ไม่สมมติว่าเอวกับสะโพกกระโปรงต่างกัน 10 นิ้วทุกไซส์</p>
        <DataComponent id="panisa-skirt-original-charts" queryId="shirt_chart_images" kind="table" title="ภาพตารางไซส์ต้นฉบับ" sourceRows={charts} displayRows={charts}>
          <div className="shirt-original-charts" data-reviewed-rows>{charts.map(c=><figure key={c.imageUrl}><a href={c.imageUrl} target="_blank" rel="noreferrer"><img loading="lazy" src={c.imageUrl} alt={`ตารางไซส์ ${c.name}`}/></a><figcaption>{c.name} · กดภาพเพื่อขยาย</figcaption></figure>)}</div>
        </DataComponent>
      </details>
      <div className="shirt-matrix-detail" aria-live="polite" data-reviewed-rows>
        <strong>สะโพก {point.hip} / เอว {point.waist} → {selected.label}</strong>
        <div>ส่วนต่าง {selected.gap} นิ้ว · {selected.reason}</div>
        {selected.options.map(r=><div key={r.size}>{selected.status==='review'?'ขนาดสำหรับตรวจ ยังไม่ยืนยัน: ':''}{r.size} · เอวกระโปรง {r.waist} (ต่าง {r.waist-point.waist}) · สะโพกกระโปรง {r.hip} (ต่าง {r.hip-point.hip}) นิ้ว</div>)}
        {selected.compared && <div>เทียบสองไซส์: {selected.compared.map(r=><div key={r.size}>{r.size} · เอว {r.waist} / สะโพก {r.hip} — {r.assessment}</div>)}</div>}
        {selected.reply && <p>ตัวอย่างตอบลูกค้า: “{selected.reply}”</p>}
        {selected.status==='custom' && <p>ค่า custom กระโปรงยังไม่ยืนยัน ต้องเช็กราคาก่อนสรุปยอด</p>}
      </div>
      <div className="shirt-matrix-scroll" tabIndex={0} role="region" aria-label="ตารางสะโพกเอวกระโปรง เลื่อนเพื่อดูครบ" data-reviewed-rows>
        <table><caption>ไซส์กระโปรง — {labels[model]}</caption><thead><tr><th scope="col">เอว ↓ / สะโพก →</th>{hips.map(h=><th scope="col" key={h} className={h===point.hip?'axis-selected':''}>{h}</th>)}</tr></thead>
          <tbody>{waists.map(w=><tr key={w}><th scope="row" className={w===point.waist?'axis-selected':''}>{w}</th>{hips.map(h=>{const f=fit(h,w),active=h===point.hip&&w===point.waist;return <td key={h} className={[active?'selected':h===point.hip||w===point.waist?'crosshair':'',h-w===10?'skirt-gap-ten':''].filter(Boolean).join(' ')}><button type="button" className={f.status==='size'?'has-size':'review-size'} title={h-w===10?'สะโพก − เอว = 10 นิ้ว':undefined} aria-pressed={active} aria-label={`สะโพก ${h} เอว ${w}: ${f.label}`} onClick={()=>setPoint({hip:h,waist:w})}>{f.label}</button></td>;})}</tr>)}</tbody>
        </table>
      </div>
      <p>* = สะโพกหลวม แนะนำช่างใกล้บ้านเก็บเข้า ไม่เสนอ custom ก่อน · ! = สะโพกคับ ต้องตรวจ · ตรวจเอว = เอวอยู่นอกช่วงไซส์ของรุ่น · ตรวจเพิ่ม = ยังสรุปตามกฎไม่ได้ · Custom = เสนองาน custom ตามช่วงสัดส่วน ไม่ใช่ราคา 50 บาทของเสื้อ</p>
    </DataComponent>
  </section>;
}
