import React,{useState} from 'react';
import {DataComponent,useDataApp} from '../../data-app-public.jsx';
import {skirtFit,skirtSizeLabel} from './skirt-matrix.js';
import './shirt-matrix.css';
const hips=Array.from({length:17},(_,i)=>32+i), waists=Array.from({length:17},(_,i)=>22+i);
export function SkirtSizeMatrix(){
  const {queries}=useDataApp();
  const [point,setPoint]=useState({hip:35,waist:25});
  const query=queries.skirt_size_chart;
  const sourceRows=query?.rows??[];
  const rows=Array.from(new Map(sourceRows.map(row=>[row.size,row])).values());
  const charts=queries.shirt_chart_images?.rows??[];
  const fit=(h,w)=>skirtFit(rows,h,w,query?.customPlans,query?.customPolicy), selected=fit(point.hip,point.waist);
  const displayRows=waists.flatMap(w=>hips.map(h=>{const f=fit(h,w);return {model:'ทุกรุ่น',bodyHip:h,bodyWaist:w,gap:f.gap,result:f.label,status:f.status,reason:f.reason,customInstructions:(f.plans??[]).map(p=>`${p.instruction}; หลังปรับ ${p.waist}/${p.hip}; ${p.ease}; ${p.warning}`).join(' หรือ ')};}));
  return <section className="shirt-matrix" id="skirt-size-matrix">
    <DataComponent id="panisa-skirt-matrix" queryId="skirt_size_chart" kind="table" variant="card" title="ตารางเลือกไซส์กระโปรงทุกรุ่น · เอว 22–38 / สะโพก 32–48" sourceRows={sourceRows} displayRows={displayRows}>
      <p>ใช้เอวและสะโพกเลือกไซส์ได้กับกระโปรงทุกรุ่น ส่วน<strong>ความยาวกระโปรง</strong>ให้ดูตามรุ่นและแบบของสินค้าที่ลูกค้าเลือก</p>
      <p>เอวตัวจริงแนวตั้ง ↓ · สะโพกตัวจริงแนวนอน → · หน่วยนิ้ว · กดช่องเพื่อดูขนาดและวิธีปรับ</p>
      <p><span className="skirt-gap-ten-key" aria-hidden="true"/> สีทอง = เอวและสะโพกตรงไซส์มาตรฐาน · * = ต้องแจ้งลูกค้าว่าสะโพกหลวม 2 นิ้ว · C = Custom</p>
      <details><summary>ดูเกณฑ์เลือกไซส์และตารางความยาวแยกตามรุ่น</summary>
        <p>เลือกไซส์ปกติเมื่อเอวกระโปรงหลวมจากตัวลูกค้า 0–1 นิ้ว และสะโพกหลวม 0–2 นิ้วพร้อมกัน นอกเกณฑ์ให้เป็น Custom โดยเทียบขนาดจริงของแต่ละไซส์</p>
        <p>XS 24/34 · S 26/36 · M 28/38 · L 30/40 · XL 32/42 · 2XL 34/44 · 3XL 36/45 · 4XL 38/47 (เอว/สะโพก) · 2XL = XXL</p>
        <p>เจ้าของร้านเพิ่ม 4XL เอว 38 / สะโพก 47 นิ้วจากตารางภาพเดิม · เอว 22 / สะโพก 32–34 เป็น Custom · ช่องที่สะโพกมากกว่าเอวตั้งแต่ 13 นิ้วขึ้นไปเว้นว่างตามที่เจ้าของร้านกำหนด</p>
        <DataComponent id="panisa-skirt-original-charts" queryId="shirt_chart_images" kind="table" title="ภาพตารางไซส์ต้นฉบับ" sourceRows={charts} displayRows={charts}>
          <div className="shirt-original-charts" data-reviewed-rows>{charts.map(c=><figure key={c.imageUrl}><a href={c.imageUrl} target="_blank" rel="noreferrer"><img loading="lazy" src={c.imageUrl} alt={`ตารางไซส์ ${c.name}`}/></a><figcaption>{c.name} · กดภาพเพื่อขยาย</figcaption></figure>)}</div>
        </DataComponent>
      </details>
      <div className="shirt-matrix-detail" aria-live="polite" data-reviewed-rows>
        <strong>เอว {point.waist} / สะโพก {point.hip} → {selected.label==='C'?'Custom':selected.label}</strong>
        <div>{selected.reason}</div>
        {selected.options.map(r=><div key={r.size}>{skirtSizeLabel(r.size)} · เอวกระโปรง {r.waist} / สะโพกกระโปรง {r.hip} นิ้ว</div>)}
        {selected.status==='custom' && <p><strong>ส่วนของช่าง:</strong> แจ้งสัดส่วนลูกค้า เอว {point.waist} / สะโพก {point.hip} นิ้วให้ช่างทราบ</p>}
        {selected.plans?.map((p,i)=><div key={`${p.size}-${i}`}><strong>{selected.plans.length>1?`ทางเลือก ${i+1}: `:'ใช้ '}{p.instruction}</strong><div>งานสำเร็จ เอว {p.waist} / สะโพก {p.hip} นิ้ว · {p.ease}</div>{p.warning&&<strong>{p.warning}</strong>}</div>)}
        {selected.status==='custom' && !selected.plans?.length && <p>คู่นี้ยังไม่ได้ระบุไซส์ตั้งต้นและวิธีปรับ ให้เช็กกับช่างและระบุเอว/สะโพกหลังปรับก่อนรับออร์เดอร์</p>}
        {selected.reply && <p>ตัวอย่างตอบลูกค้า: “{selected.reply}”</p>}
        {selected.status==='custom' && <p><strong>การสรุปราคา:</strong> ราคาปกติ + ค่า Custom {selected.customFee} บาท · งาน Custom เปลี่ยนสินค้าไม่ได้ครับผม</p>}
      </div>
      <div className="shirt-matrix-scroll" tabIndex={0} role="region" aria-label="ตารางสะโพกเอวกระโปรง เลื่อนเพื่อดูครบ" data-reviewed-rows>
        <table><caption>ไซส์กระโปรงทุกรุ่น (เอว / สะโพก)</caption><thead><tr><th scope="col">เอว ↓ / สะโพก →</th>{hips.map(h=><th scope="col" key={h} className={h===point.hip?'axis-selected':''}>{h}</th>)}</tr></thead>
          <tbody>{waists.map(w=><tr key={w}><th scope="row" className={w===point.waist?'axis-selected':''}>{w}</th>{hips.map(h=>{const f=fit(h,w),active=h===point.hip&&w===point.waist,exact=f.status==='size'&&f.options[0].waist===w&&f.options[0].hip===h;if(f.status==='blank')return <td key={h} aria-label={`เอว ${w} สะโพก ${h}: ช่องว่าง`}/>;return <td key={h} className={[active?'selected':h===point.hip||w===point.waist?'crosshair':'',exact?'skirt-gap-ten':''].filter(Boolean).join(' ')}><button type="button" className={f.status==='size'?'has-size':'review-size'} title={f.reason} aria-pressed={active} aria-label={`เอว ${w} สะโพก ${h}: ${f.label}`} onClick={()=>setPoint({hip:h,waist:w})}>{f.label}</button></td>;})}</tr>)}</tbody>
        </table>
      </div>
      <p>C = Custom · * = สะโพกหลวม 2 นิ้ว ต้องแจ้งลูกค้า · 2XL = XXL</p>
    </DataComponent>
  </section>;
}
