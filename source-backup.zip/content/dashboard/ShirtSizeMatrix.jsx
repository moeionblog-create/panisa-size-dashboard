import React, {useState} from 'react';
import {DataComponent, Dropdown, useDataApp} from '../../data-app-public.jsx';
import {shirtCandidates} from './shirt-matrix.js';
import './shirt-matrix.css';

const labels={artificial_silk_v1:'ไหมเทียม',woven_sets_v1:'ลูกแก้ว / ข้าวหลามตัด / เหลืองกนก / น้ำเงินขิด / ฟ้าบีต้า',galan_v1:'กาแลนด์'};
const chests=Array.from({length:19},(_,i)=>30+i);
const waists=Array.from({length:25},(_,i)=>22+i);
export function ShirtSizeMatrix(){
  const {queries}=useDataApp();
  const [model,setModel]=useState(() => window.location.hash === '#galan-shirt-size' ? 'galan_v1' : 'artificial_silk_v1');
  const [point,setPoint]=useState({chest:32,waist:24});
  const galan = model === 'galan_v1';
  const waistAxis = galan ? [...waists, 28.5].sort((a,b)=>a-b) : waists;
  const noSize = galan ? 'เช็กไซส์กับร้าน' : 'เช็กสั่งปรับ';
  const rows=(queries.shirt_size_chart?.rows??[]).filter(r=>r.model===model);
  const photos=(queries.shirt_product_images?.rows??[]).filter(r=>r.model===model);
  const charts=(queries.shirt_chart_images?.rows??[]).filter(r=>r.model===model);
  const calculate=(chest,waist)=>shirtCandidates(rows,chest,waist);
  const selected=calculate(point.chest,point.waist);
  const displayRows=waistAxis.flatMap(waist=>chests.map(chest=>{
    const c=calculate(chest,waist);
    return {model:labels[model],bodyChest:chest,bodyWaist:waist,chestEase:c.options.map(r=>r.chest-chest).join(' / '),candidateSizes:c.options.map(r=>r.size).join(' / '),reviewOnly:!c.matches.length,status:c.options.map(r=>r.waistStatus).join(' / ') || noSize};
  }));
  return <section id="galan-shirt-size" className="shirt-matrix">
    <DataComponent id="panisa-shirt-matrix" queryId="shirt_size_chart" kind="table" variant="card"
      title="ตารางไขว้เลือกไซส์เสื้อ · อกก่อน เอวทีหลัง" sourceRows={rows} displayRows={displayRows}
      description="ใช้ขนาดเสื้อจริงจากภาพตาราง ตรวจครบทั้งสามกลุ่ม 16 ต.ค. 2026 (ภาพไหมเทียม 16 ต.ค. / ผ้าทอและกาแลนด์ 15 ต.ค.) ไม่ใช่สถิติไซส์ที่ลูกค้าซื้อ ตัวกรองปีด้านล่างไม่เปลี่ยนตารางนี้"
      headerControls={<>
        <Dropdown label="รุ่นเสื้อ" showLabel choices={Object.keys(labels)} choiceLabels={labels} value={model} onChange={next=>{setModel(next); if(next !== 'galan_v1' && point.waist === 28.5) setPoint({...point,waist:28});}}/>
      </>}>
      <details><summary>ดูภาพสินค้าและตารางไซส์ต้นฉบับ</summary>
      <DataComponent id="panisa-shirt-product-photos" queryId="shirt_product_images" kind="table" title="ภาพสินค้าของรุ่นที่เลือก" sourceRows={photos} displayRows={photos}>
        <div className="shirt-product-photos" data-reviewed-rows>
          {photos.map(photo=><figure key={photo.name}>
            <a href={photo.imageUrl} target="_blank" rel="noreferrer" aria-label={`ดูภาพใหญ่ ${photo.name}`}><ProductPhoto key={photo.imageUrl} photo={photo}/></a>
            <figcaption><strong>{photo.name}</strong> · {photo.caption} <a href={photo.productUrl} target="_blank" rel="noreferrer">ดูในคลังภาพร้าน ↗</a></figcaption>
          </figure>)}
        </div>
      </DataComponent>
      <DataComponent id="panisa-original-size-charts" queryId="shirt_chart_images" kind="table" title="ภาพตารางไซส์ต้นฉบับ · กดภาพเพื่อขยาย" sourceRows={charts} displayRows={charts}>
        <p>ตัวเลขในภาพคือขนาดเสื้อผ้าจริง ไม่ใช่สัดส่วนตัวลูกค้า ตรวจครบทั้งสามกลุ่ม 16 ต.ค. 2026 (ภาพไหมเทียม 16 ต.ค. / ผ้าทอและกาแลนด์ 15 ต.ค.); คำแนะนำการเผื่อในตารางไขว้ใช้กฎล่าสุดที่ร้านแจ้ง</p>
        <div className="shirt-original-charts" data-reviewed-rows>{charts.map(chart=><figure key={chart.name}>
          <a href={chart.imageUrl} target="_blank" rel="noreferrer" aria-label={`เปิดตารางไซส์ ${chart.name} ขนาดเต็ม`}><ProductPhoto key={chart.imageUrl} photo={chart}/></a>
          <figcaption>{chart.name} · ตารางวันที่ {chart.verifiedDate} · <a href={chart.imageUrl} target="_blank" rel="noreferrer">เปิดตารางขนาดเต็ม ↗</a></figcaption>
        </figure>)}</div>
      </DataComponent>
      </details>
      <p>แกน X = รอบอกตัวจริง · แกน Y = รอบเอวตัวจริง · หน่วยนิ้ว กดช่องเพื่อดูขนาดเสื้อและระยะเผื่อ</p>
      <p className="shirt-matrix-note">กฎร้าน: XS / S / M / L เผื่ออก 2 นิ้ว · XL / 2XL เผื่ออก 2–3 นิ้ว · 3XL ขึ้นไปเผื่ออก 2–4 นิ้ว แล้วตรวจเอว {galan ? 'สำหรับกาแลนด์ อกจริง 32 นิ้วเลือก XS ได้เลย แนะนำชุดสำเร็จรูปก่อน แจ้งเรื่องปรับเอวเฉพาะเมื่อลูกค้าถาม' : 'ถ้าเอวเสื้อเล็กกว่าเอวตัวจริง ให้เสนอปรับช่วงเอว ไม่ขยับไซส์ขึ้นอัตโนมัติ'} หากเข้าเกณฑ์หลายไซส์ จะแสดงทุกตัวเลือกพร้อมส่วนต่างเอวให้พิจารณา ตารางใช้ชื่อ XXL แทน 2XL</p>
      <div className="shirt-matrix-detail" aria-live="polite" data-reviewed-rows>
        <strong>อก {point.chest} / เอว {point.waist} → {selected.options.map(r=>r.size+(r.reviewOnly?' ≈ รอตรวจทรง':'')).join(' / ') || noSize}</strong>
        {selected.options.length ? selected.options.map(r=><div key={r.size}>{r.reviewOnly && <p>ตัวเลือกใกล้เคียงสำหรับร้านตรวจ: ระยะเผื่ออกเกินเกณฑ์ ยังไม่ยืนยันไซส์ให้ลูกค้า</p>}{r.size}: อกเสื้อ {r.chest} (เผื่อ {r.chest-point.chest}) · เอวเสื้อ {r.waist} (ส่วนต่าง {r.waist-point.waist}) นิ้ว · {r.waistStatus}
          {galan && !r.reviewOnly && r.waist < point.waist && <p>“ช่วงอกใส่ไซส์ {r.size} ได้ค่ะ แต่เอวเสื้อวัดได้ {r.waist} นิ้ว ช่วงเอวจะคับค่ะ”</p>}
          {galan && !r.reviewOnly && point.chest === 32 && r.size === 'XS' && point.waist <= r.waist && <p>“แนะนำ XS ได้เลยค่ะ อกและเอวของคุณลูกค้าใส่ไซส์นี้ได้ ใส่สวยเหมือนนางแบบเลยค่ะ”</p>}
          {!galan && r.waist < point.waist && <p>ตัวอย่างตอบลูกค้า: “{r.reviewOnly?'มีตัวเลือกใกล้เคียงคือ':'ตามรอบอกเป็นไซส์'} {r.size} ครับผม แต่เอวเสื้อเล็กกว่าเอวตัวจริง {point.waist-r.waist} นิ้ว ขอเช็กกับช่างว่ารุ่นนี้ขยายช่วงเอวได้ไหม รวมถึงขนาดหลังปรับ ค่าแก้ และระยะเวลาก่อนยืนยันครับ”</p>}
          {(!galan || point.chest !== 32 || r.size !== 'XS') && r.waist === point.waist && <p>ตัวอย่างตอบลูกค้า: “เอวเสื้อเท่ากับเอวคุณลูกค้า ใส่ได้ครับผม ไม่ต้องปรับเอวครับ มีผ่าหลังช่วยให้ใส่สวยเข้ารูป ใส่สวยเหมือนนางแบบรับรองได้ครับผม”{r.reviewOnly && <span> ทั้งนี้ตัวเลือกนี้ยังต้องตรวจระยะเผื่ออกและทรงก่อนยืนยันไซส์</span>}</p>}
        </div>) : galan ? <p>ขอเช็กไซส์กับทางร้านก่อนยืนยันค่ะ</p> : <div>ไม่มีไซส์มาตรฐานที่เผื่ออกได้อย่างน้อย 2 นิ้ว ขอเช็กกับช่างเรื่องปรับขนาดหรือสั่งทำก่อน ยังไม่ยืนยันว่าทำได้ ราคา หรือระยะเวลา</div>}
      </div>
      {galan && <details key={point.chest+'-'+point.waist}>
        <summary>ข้อความสำหรับแอดมิน · เปิดเมื่อลูกค้าถามเรื่องปรับเอว</summary>
        <p><strong>ลูกค้าขอขยายเอว</strong><br/>“ทางร้านปรับขยายเอวให้ฟรีค่ะ ขอรอบเอวจริงเป็นนิ้วด้วยนะคะ งานที่ปรับแล้วจะเปลี่ยนหรือคืนไม่ได้ค่ะ”</p>
        <p><strong>ลูกค้าเอวเล็กและขอปรับเข้า</strong><br/>“ทางร้านปรับเอวเข้าให้ฟรีค่ะ ขอรอบเอวจริงเป็นนิ้วด้วยนะคะ งานที่ปรับแล้วจะเปลี่ยนหรือคืนไม่ได้ค่ะ”</p>
      </details>}
      <div className="shirt-matrix-scroll" tabIndex={0} role="region" aria-label="ตารางอกเอว เลื่อนซ้ายขวาเพื่อดูครบ" data-reviewed-rows>
        <table><caption>ตัวเลือกไซส์เสื้อจากอกและเอว — {labels[model]}</caption><thead><tr><th scope="col">เอว ↓ / อก →</th>{chests.map(c=><th scope="col" key={c} className={point.chest===c?'axis-selected':''}>{c}</th>)}</tr></thead>
          <tbody>{waistAxis.map(w=><tr key={w}><th scope="row" className={point.waist===w?'axis-selected':''}>{w}</th>{chests.map(c=>{
            const fit=calculate(c,w), text=fit.options.map(r=>(r.reviewOnly?'≈':'')+r.size+(r.waist<w?'*':r.waist===w?'?':'')).join('/');
            const active=c===point.chest&&w===point.waist;
            return <td key={c} className={active?'selected':c===point.chest||w===point.waist?'crosshair':''}><button type="button" className={fit.matches.length?'has-size':'review-size'} aria-pressed={active} aria-label={`อก ${c} เอว ${w}: ${text||noSize}`} onClick={()=>setPoint({chest:c,waist:w})}>{text||noSize}</button></td>;
          })}</tr>)}</tbody></table>
      </div>
      <p>ไซส์ = อกเข้าเกณฑ์ เอวเสื้อมากกว่าตัวจริง ยังตรวจความสบาย · {galan ? '* = เอวเสื้อเล็กกว่าเอวจริง' : '* = เอวคับ เสนอปรับเอว'} · ? = เอวเท่าตัวจริง ใส่ได้ ไม่ต้องปรับเอว มีผ่าหลังช่วยให้เข้ารูป · ≈ = ไซส์ใกล้เคียงที่เผื่ออกเกินเกณฑ์ ให้ร้านตรวจทรงก่อนแนะนำ · {noSize} = ไม่มีไซส์มาตรฐานเผื่ออกถึง 2 นิ้ว เลื่อนตารางแนวนอนเพื่อดูถึงอก 48 นิ้ว ขนาดนอกตารางยังไม่สรุปไซส์</p>
    </DataComponent>
  </section>;
}
function ProductPhoto({photo}){
  const [failed,setFailed]=useState(false);
  return failed ? <span className="shirt-photo-fallback">โหลดภาพไม่ได้ · กดเปิดภาพจากคลังร้าน</span> : <img src={photo.imageUrl} alt={`${photo.name} — ${photo.caption}`} onError={()=>setFailed(true)}/>;
}
