import React, {useState} from 'react';
import {DataComponent, Dropdown, useDataApp} from '../../data-app-public.jsx';
import {shirtCandidates, shirtExpansionReply, shirtSizeReply, shirtTakeInChoices, shirtWaistReplies} from './shirt-matrix.js';
import './shirt-matrix.css';

const labels={artificial_silk_v1:'ไหมเทียม',woven_sets_v1:'ลูกแก้ว / ข้าวหลามตัด / เหลืองกนก / น้ำเงินขิด / ฟ้าบีต้า',galan_v1:'กาแลนด์'};
const chests=Array.from({length:19},(_,i)=>30+i);
const waists=Array.from({length:25},(_,i)=>22+i);
export function ShirtSizeMatrix(){
  const {queries}=useDataApp();
  const [model,setModel]=useState(() => {
    const requestedModel = new URLSearchParams(window.location.search).get('model');
    if (Object.hasOwn(labels,requestedModel)) return requestedModel;
    return window.location.hash === '#galan-shirt-size' ? 'galan_v1' : 'artificial_silk_v1';
  });
  const [point,setPoint]=useState(() => {
    const params = new URLSearchParams(window.location.search);
    const chest = Number(params.get('chest')), waist = Number(params.get('waist'));
    return chests.includes(chest) && (waists.includes(waist) || waist === 28.5)
      ? {chest,waist} : {chest:32,waist:24};
  });
  const replyPanel = React.useRef(null);
  const waistAxis = [...waists, 28.5].sort((a,b)=>a-b);
  const noSize = 'เช็กไซส์กับร้าน';
  const rows=(queries.shirt_size_chart?.rows??[]).filter(r=>r.model===model);
  const photos=(queries.shirt_product_images?.rows??[]).filter(r=>r.model===model);
  const charts=(queries.shirt_chart_images?.rows??[]).filter(r=>r.model===model);
  const calculate=(chest,waist)=>shirtCandidates(rows,chest,waist);
  const selected=calculate(point.chest,point.waist);
  const takeInChoices = shirtTakeInChoices(selected,point.waist);
  const displayRows=waistAxis.flatMap(waist=>chests.map(chest=>{
    const c=calculate(chest,waist);
    const replyFields = {customerReply:shirtSizeReply(c.options,chest,waist),replyOnlyIfAskedAboutExpansion:shirtExpansionReply(c,waist),choicesOnlyIfShopTakeInRequested:shirtTakeInChoices(c,waist)};
    return {...replyFields,model:labels[model],bodyChest:chest,bodyWaist:waist,chestEase:c.options.map(r=>r.chest-chest).join(' / '),candidateSizes:c.options.map(r=>r.size).join(' / '),reviewOnly:!c.matches.length,status:c.options.map(r=>r.waistStatus).join(' / ') || noSize};
  }));
  return <section id={window.location.hash === '#galan-shirt-size' ? 'galan-shirt-size' : 'shirt-size-matrix'} className="shirt-matrix">
    <DataComponent id="panisa-shirt-matrix" queryId="shirt_size_chart" kind="table" variant="card"
      title="ตารางไขว้เลือกไซส์เสื้อ · อกก่อน เอวทีหลัง" sourceRows={rows} displayRows={displayRows}
      description="ใช้ขนาดเสื้อจริงจากภาพตาราง ตรวจครบทั้งสามกลุ่ม 16 ต.ค. 2026 (ภาพไหมเทียม 16 ต.ค. / ผ้าทอและกาแลนด์ 15 ต.ค.) ไม่ใช่สถิติไซส์ที่ลูกค้าซื้อ ตัวกรองปีด้านล่างไม่เปลี่ยนตารางนี้"
      headerControls={<>
        <Dropdown label="รุ่นเสื้อ" showLabel choices={Object.keys(labels)} choiceLabels={labels} value={model} onChange={setModel}/>
      </>}>
      <details><summary>ดูภาพสินค้าและตารางไซส์ต้นฉบับ</summary>
      <DataComponent id="panisa-shirt-product-photos" queryId="shirt_product_images" kind="table" title="ภาพสินค้าของรุ่นที่เลือก" sourceRows={photos} displayRows={photos}>
        <div className="shirt-product-photos" data-reviewed-rows>
          {photos.map(photo=><figure key={photo.name}>
            <a href={photo.imageUrl} target="_blank" rel="noreferrer" aria-label={`ดูภาพใหญ่ ${photo.name}`}><ProductPhoto key={photo.imageUrl} photo={photo}/></a>
            <figcaption><strong>{photo.name}</strong> · {photo.caption} <a href={photo.productUrl} target="_blank" rel="noreferrer">ดูในคลังภาพร้าน ↗</a></figcaption>
          </figure>)}
        </div>
      </DataComponent>
      <DataComponent id="panisa-original-size-charts" queryId="shirt_chart_images" kind="table" title="ภาพตารางไซส์ต้นฉบับ · กดภาพเพื่อขยาย" sourceRows={charts} displayRows={charts}>
        <p>ตัวเลขในภาพคือขนาดเสื้อผ้าจริง ไม่ใช่สัดส่วนตัวลูกค้า ตรวจครบทั้งสามกลุ่ม 16 ต.ค. 2026 (ภาพไหมเทียม 16 ต.ค. / ผ้าทอและกาแลนด์ 15 ต.ค.); คำแนะนำการเผื่อในตารางไขว้ใช้กฎล่าสุดที่ร้านแจ้ง</p>
        <div className="shirt-original-charts" data-reviewed-rows>{charts.map(chart=><figure key={chart.name}>
          <a href={chart.imageUrl} target="_blank" rel="noreferrer" aria-label={`เปิดตารางไซส์ ${chart.name} ขนาดเต็ม`}><ProductPhoto key={chart.imageUrl} photo={chart}/></a>
          <figcaption>{chart.name} · ตารางวันที่ {chart.verifiedDate} · <a href={chart.imageUrl} target="_blank" rel="noreferrer">เปิดตารางขนาดเต็ม ↗</a></figcaption>
        </figure>)}</div>
      </DataComponent>
      </details>
      <p>แกน X = รอบอกตัวจริง · แกน Y = รอบเอวตัวจริง · หน่วยนิ้ว กดช่องเพื่อดูขนาดเสื้อและระยะเผื่อ</p>
      <p className="shirt-matrix-note">กฎร้าน: XS / S / M / L เผื่ออก 2 นิ้ว · XL / 2XL เผื่ออก 2–3 นิ้ว · 3XL ขึ้นไปเผื่ออก 2–4 นิ้ว แล้วตรวจเอว อกจริง 32 นิ้วเข้าเกณฑ์ XS ให้ตรวจเอวเสื้อจากตารางของรุ่นที่เลือก แนะนำชุดสำเร็จรูปก่อน แจ้งเรื่องปรับเอวเฉพาะเมื่อลูกค้าถาม หากเข้าเกณฑ์หลายไซส์ จะแสดงทุกตัวเลือกพร้อมส่วนต่างเอวให้พิจารณา ตารางใช้ชื่อ XXL แทน 2XL</p>
      <div ref={replyPanel} className="shirt-matrix-detail" aria-live="polite" data-reviewed-rows>
        <strong>อก {point.chest} / เอว {point.waist} → {selected.options.map(r=>r.size+(r.reviewOnly?' ≈ รอตรวจทรง':r.waist < point.waist?' · พอดีช่วงอก แต่เอวคับ':'')).join(' / ') || noSize}</strong>
        {selected.options.map(r=><div key={r.size}>
          {r.reviewOnly && <p>ตัวเลือกใกล้เคียงสำหรับร้านตรวจ ระยะเผื่ออกเกินเกณฑ์ ยังต้องตรวจทรงก่อนยืนยันไซส์</p>}
          {r.size}: อกเสื้อ {r.chest} (เผื่อ {r.chest-point.chest}) · เอวเสื้อ {r.waist} (ส่วนต่าง {Number((r.waist-point.waist).toFixed(1))}) นิ้ว · {r.waistStatus}
        </div>)}
        <p><strong>ตัวอย่างตอบลูกค้าเมื่อถามไซส์</strong><br/>“{shirtSizeReply(selected.options,point.chest,point.waist)}”</p>
      </div>
      <details key={model+'-'+point.chest+'-'+point.waist}>
        <summary>ข้อความสำหรับแอดมิน · เปิดเมื่อลูกค้าถามเรื่องปรับเอว</summary>
        <p><strong>ลูกค้าขอขยายเอว</strong><br/>“{shirtExpansionReply(selected,point.waist) || shirtWaistReplies.expand}”</p>
        <p><strong>ลูกค้าเอวเล็กและขอปรับเข้า</strong><br/>“{shirtWaistReplies.takeIn}”</p>
        {takeInChoices.length > 0 && <div>
          <p><strong>เมื่อลูกค้าเลือกให้ร้านปรับเอวเข้า</strong></p>
          <p style={{whiteSpace:'pre-line'}}>{shirtWaistReplies.askEaseAfterShopTakeInRequested}</p>
          {takeInChoices.map(choice=><details key={choice.inches}>
            <summary>ลูกค้าตอบ {choice.inches} · รอบเอวเสื้อที่ต้องการ {choice.targetWaist} นิ้ว</summary>
            <p>{choice.customerReply}</p>
          </details>)}
        </div>}
      </details>
      <button type="button" onClick={()=>downloadShirtReplies(displayRows,model)}>ดาวน์โหลดตัวอย่างตอบลูกค้าสำหรับ AI (JSON)</button>
      <div className="shirt-matrix-scroll" tabIndex={0} role="region" aria-label="ตารางอกเอว เลื่อนซ้ายขวาเพื่อดูครบ" data-reviewed-rows>
        <table><caption>ตัวเลือกไซส์เสื้อจากอกและเอว — {labels[model]}</caption><thead><tr><th scope="col">เอว ↓ / อก →</th>{chests.map(c=><th scope="col" key={c} className={point.chest===c?'axis-selected':''}>{c}</th>)}</tr></thead>
          <tbody>{waistAxis.map(w=><tr key={w}><th scope="row" className={point.waist===w?'axis-selected':''}>{w}</th>{chests.map(c=>{
            const fit=calculate(c,w), text=fit.options.map(r=>(r.reviewOnly?'≈':'')+r.size+(r.waist<w?'*':r.waist===w?'?':'')).join('/');
            const active=c===point.chest&&w===point.waist;
            return <td key={c} className={active?'selected':c===point.chest||w===point.waist?'crosshair':''}><button type="button" className={fit.matches.length?'has-size':'review-size'} aria-pressed={active} aria-label={`อก ${c} เอว ${w}: ${text||noSize}`} onClick={()=>{
              setPoint({chest:c,waist:w});
              replyPanel.current?.scrollIntoView({block:'center'});
            }}>{text||noSize}</button></td>;
          })}</tr>)}</tbody></table>
      </div>
      <p>ไซส์ = อกเข้าเกณฑ์ เอวเสื้อมากกว่าตัวจริง ยังตรวจความสบาย · * = เอวเสื้อเล็กกว่าเอวจริง · ? = เอวเท่าตัวจริง ใส่ได้ ไม่ต้องปรับเอว มีผ่าหลังช่วยให้เข้ารูป · ≈ = ไซส์ใกล้เคียงที่เผื่ออกเกินเกณฑ์ ให้ร้านตรวจทรงก่อนแนะนำ · {noSize} = ไม่มีไซส์มาตรฐานเผื่ออกถึง 2 นิ้ว เลื่อนตารางแนวนอนเพื่อดูถึงอก 48 นิ้ว ขนาดนอกตารางยังไม่สรุปไซส์</p>
    </DataComponent>
  </section>;
}
function downloadShirtReplies(rows,model) {
  const guide = {
    model: 'เสื้อ'+labels[model], unit: 'นิ้ว',
    instructions: 'ใช้รอบอกและรอบเอวที่วัดจากตัวจริง ถ้าลูกค้าแจ้งตัวเลขเดียวให้ถามว่าเป็นขนาดตัวหรือขนาดเสื้อ และขอรอบเอวก่อนยืนยันไซส์ ใช้ customerReply เมื่อลูกค้าถามไซส์ และใช้คำตอบเรื่องปรับเอวเฉพาะเมื่อลูกค้าถาม',
    customerAskedAboutWaistAlteration: shirtWaistReplies,
    sizeExamples: rows,
  };
  const url = URL.createObjectURL(new Blob([JSON.stringify(guide,null,2)],{type:'application/json;charset=utf-8'}));
  const link = document.createElement('a');
  link.href = url;
  link.download = `panisa-${model.replace(/_v1$/,'').replaceAll('_','-')}-size-replies.json`;
  link.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

function ProductPhoto({photo}){
  const [failed,setFailed]=useState(false);
  return failed ? <span className="shirt-photo-fallback">โหลดภาพไม่ได้ · กดเปิดภาพจากคลังร้าน</span> : <img src={photo.imageUrl} alt={`${photo.name} — ${photo.caption}`} onError={()=>setFailed(true)}/>;
}
