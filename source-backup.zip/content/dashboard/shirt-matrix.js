export function shirtCandidates(rows, chest, waist) {
  const chestMatches = rows.filter(r => {
    const ease = r.chest - chest;
    if (['XS','S','M','L'].includes(r.size)) return ease === 2;
    if (['XL','XXL','2XL'].includes(r.size)) return ease >= 2 && ease <= 3;
    if (/^[3-9]XL$/.test(r.size)) return ease >= 2 && ease <= 4;
    return false;
  })
    .map(r=>({...r,waistStatus:r.waist<waist?'เอวคับ · เสนอปรับช่วงเอว':r.waist===waist?'เอวเท่าตัวจริง · เสนอปรับช่วงเอวเพิ่มความสบาย':'เอวเสื้อมากกว่าตัวจริง · ตรวจความสบายและทรง'}));
  // Review-only fallback: never recommend a garment with less than 2 inches of chest ease.
  const looseOptions = rows.filter(r => r.chest - chest >= 2);
  const nearestEase = Math.min(...looseOptions.map(r => r.chest - chest));
  const alternatives = chestMatches.length ? [] : looseOptions
    .filter(r => r.chest - chest === nearestEase)
    .map(r => ({...r, reviewOnly:true, waistStatus:r.waist<waist?'เอวคับ · เสนอเช็กปรับช่วงเอวกับช่าง':r.waist===waist?'เอวเท่าตัวจริง · เสนอเช็กปรับเอวเพื่อความสบาย':'เอวเสื้อมากกว่าตัวจริง · ตรวจทรงและความสบาย'}));
  return {
    matches: chestMatches,
    chestMatches,
    alternatives,
    options: chestMatches.length ? chestMatches : alternatives,
  };
}
