export function shirtCandidates(rows, chest, waist) {
  const chestMatches = rows.filter(r => {
    if (r.model === 'galan_v1' && r.size === 'XS' && chest === 32) return true;
    const ease = r.chest - chest;
    if (['XS','S','M','L'].includes(r.size)) return ease === 2;
    if (['XL','XXL','2XL'].includes(r.size)) return ease >= 2 && ease <= 3;
    if (/^[3-9]XL$/.test(r.size)) return ease >= 2 && ease <= 4;
    return false;
  })
    .map(r=>({...r,waistStatus:r.waist<waist?(r.model==='galan_v1'?'เอวเสื้อเล็กกว่าเอวจริง':'เอวคับ · เสนอปรับช่วงเอว'):r.waist===waist?'เอวเท่าตัวจริง · ใส่ได้ ไม่ต้องปรับเอว':'เอวเสื้อมากกว่าตัวจริง · ตรวจความสบายและทรง'}));
  // Review-only fallback: never recommend a garment with less than 2 inches of chest ease.
  const looseOptions = rows.filter(r => r.chest - chest >= 2);
  const nearestEase = Math.min(...looseOptions.map(r => r.chest - chest));
  const alternatives = chestMatches.length ? [] : looseOptions
    .filter(r => r.chest - chest === nearestEase)
    .map(r => ({...r, reviewOnly:true, waistStatus:r.waist<waist?(r.model==='galan_v1'?'เอวเสื้อเล็กกว่าเอวจริง':'เอวคับ · เสนอเช็กปรับช่วงเอวกับช่าง'):r.waist===waist?'เอวเท่าตัวจริง · ใส่ได้ ไม่ต้องปรับเอว':'เอวเสื้อมากกว่าตัวจริง · ตรวจทรงและความสบาย'}));
  return {
    matches: chestMatches,
    chestMatches,
    alternatives,
    options: chestMatches.length ? chestMatches : alternatives,
  };
}

const takeInEaseOptions = [
  {inches:1, fit:'เข้ารูป ดูเป๊ะและเนี้ยบ'},
  {inches:2, fit:'พอดีตัว ไม่หลวมไม่คับ'},
  {inches:3, fit:'หลวมสบาย ไม่เน้นสัดส่วน เผื่อน้ำหนักขึ้น'},
  {inches:4, fit:'หลวมสบายขึ้นอีกนิด ไม่เน้นสัดส่วน เผื่อน้ำหนักขึ้น'},
];

export const galanWaistReplies = {
  policy: 'ตอบเรื่องปรับเอวเฉพาะเมื่อลูกค้าถาม เริ่มจากการลองไซส์สำเร็จรูปก่อน',
  expand: 'คุณลูกค้ารับไซส์ปกติไปลองก่อนได้ค่ะ ถ้าอยากให้ช่วงเอวสบายขึ้น ค่อยให้ช่างแถวบ้านดูว่าขยายได้ตามที่ต้องการไหม หรือถ้าสะดวกให้ทางร้านขยายเอวให้ ทางร้านปรับให้ฟรีค่ะ งานที่ร้านปรับแล้วจะเปลี่ยนหรือคืนไม่ได้ค่ะ หากเลือกให้ร้านปรับ รบกวนแจ้งรอบเอวจริงเป็นนิ้วนะคะ',
  takeIn: 'คุณลูกค้ารับไซส์ปกติไปลองก่อนได้ค่ะ ถ้าอยากให้ช่วงเอวเข้ารูปขึ้น ค่อยให้ช่างแถวบ้านปรับเข้าตามที่ชอบ หรือจะให้ทางร้านปรับเอวเข้าให้ฟรีก็ได้ค่ะ งานที่ร้านปรับแล้วจะเปลี่ยนหรือคืนไม่ได้ค่ะ หากเลือกให้ร้านปรับ รบกวนแจ้งรอบเอวจริงเป็นนิ้วนะคะ',
  takeInEaseOptions,
  askEaseAfterShopTakeInRequested: [
    'อยากให้ช่วงเอวเสื้อหลวมกว่ารอบเอวจริงกี่นิ้วคะ?',
    ...takeInEaseOptions.map(option => `${option.inches} นิ้ว — ${option.fit}`),
    'ตอบแค่ 1 / 2 / 3 / 4 ได้เลยค่ะ',
  ].join('\n'),
  afterEaseChoice: 'หลังถามเรื่องระยะเผื่อเอวแล้ว ให้ใช้เลข 1–4 ที่ลูกค้าตอบเป็นนิ้วที่เผื่อหลวม ขอรอบเอวจริงเฉพาะเมื่อยังไม่ทราบ แล้วคำนวณเอวเสื้อที่ต้องการ = รอบเอวจริง + นิ้วที่เลือก เทียบกับเอวเสื้อสำเร็จรูปของไซส์ที่เลือก ถ้าเท่ากันให้แนะนำทรงเดิม ถ้าเป้าหมายใหญ่กว่าให้เช็กไซส์หรือเช็กกับช่างก่อนยืนยัน ถ้าเล็กกว่าให้ทวนรอบเอวเสื้อหลังปรับกับลูกค้า แจ้งว่าร้านปรับฟรีและงานที่ปรับแล้วเปลี่ยนหรือคืนไม่ได้ก่อนยืนยัน',
};

export function galanExpansionReply(fit, waist) {
  if (fit.matches.length !== 1) return '';
  const row = fit.matches[0];
  if (row.waist >= waist) return '';
  const shortfall = Number((waist - row.waist).toFixed(1));
  return `ไซส์ ${row.size} ต้องขยายช่วงเอวอย่างน้อย ${shortfall} นิ้วถึงจะเท่ากับเอว ${waist} นิ้วค่ะ คุณลูกค้ารับไซส์ปกติไปลองแล้วให้ช่างแถวบ้านดูว่าขยายได้พอไหม หรือให้ทางร้านเช็กกับช่างก่อนว่าขยายได้ถึงขนาดที่ต้องการค่ะ ทางร้านปรับเอวให้ฟรี งานที่ร้านปรับแล้วจะเปลี่ยนหรือคืนไม่ได้ค่ะ`;
}

export function galanTakeInChoices(fit, waist) {
  if (fit.matches.length !== 1) return [];
  const shirt = fit.matches[0];
  if (shirt.waist <= waist) return [];
  return takeInEaseOptions.map(({inches}) => {
    const target = waist + inches;
    const summary = `เอวจริง ${waist} นิ้ว เลือกเผื่อ ${inches} นิ้ว รอบเอวเสื้อที่ต้องการคือ ${target} นิ้วค่ะ`;
    let reply;
    if (target === shirt.waist) {
      reply = `ไซส์ ${shirt.size} เอวเสื้อ ${shirt.waist} นิ้วพอดี รับไซส์ปกติได้เลยค่ะ`;
    } else if (target > shirt.waist) {
      reply = `ไซส์ ${shirt.size} เอวเสื้อ ${shirt.waist} นิ้ว เล็กกว่ารอบเอวเสื้อที่ต้องการค่ะ เดี๋ยวทางร้านขอเช็กไซส์ให้ก่อนนะคะ`;
    } else {
      reply = `ทางร้านปรับเอวไซส์ ${shirt.size} เข้าให้เหลือ ${target} นิ้วได้ฟรีค่ะ งานที่ปรับแล้วจะเปลี่ยนหรือคืนไม่ได้ คุณลูกค้ายืนยันรอบเอวเสื้อ ${target} นิ้วไหมคะ?`;
    }
    return {inches,targetWaist:target,customerReply:`${summary} ${reply}`};
  });
}

export function galanSizeReply(options, chest, waist) {
  if (!options.length) {
    return `จากรอบอก ${chest} นิ้วและเอว ${waist} นิ้ว ยังไม่มีไซส์สำเร็จรูปในตารางที่เผื่อช่วงอกได้พอค่ะ ขอให้ทางร้านเช็กก่อนยืนยันไซส์นะคะ`;
  }
  const replies = options.map(row => {
    const ease = Number((row.waist - waist).toFixed(1));
    const waistFit = ease < 0 ? `เอวเสื้อเล็กกว่าเอวคุณลูกค้า ${-ease} นิ้ว ช่วงเอวจะคับค่ะ`
      : ease === 0 ? 'เอวเสื้อเท่ากับเอวคุณลูกค้าพอดีค่ะ'
      : `ช่วงเอวจะเหลือ ${ease} นิ้วค่ะ`;
    if (row.reviewOnly) {
      return `ไซส์ใกล้เคียงคือ ${row.size} ค่ะ อกเสื้อ ${row.chest} นิ้ว เหลือช่วงอก ${row.chest - chest} นิ้ว ซึ่งหลวมกว่าเกณฑ์ของรุ่นนี้ ส่วนเอวเสื้อ ${row.waist} นิ้ว ${waistFit} ขอให้ทางร้านเช็กทรงก่อนยืนยันไซส์นะคะ`;
    }
    if (row.size === 'XS' && chest === 32 && ease >= 0) {
      return 'อก 32 นิ้ว ใส่ XS ได้เลยค่ะ เอวเสื้อ 28.5 นิ้ว ใส่สวยเหมือนนางแบบเลยค่ะ';
    }
    if (row.size === 'XS' && chest === 32 && ease < 0) {
      return `อก ${chest} นิ้วตรงกับไซส์ XS ค่ะ แต่เอวเสื้อ ${row.waist} นิ้ว เล็กกว่าเอวคุณลูกค้า ${waist} นิ้วอยู่ ${-ease} นิ้ว ถ้าติดกระดุม ช่วงเอวจะคับค่ะ สำหรับสัดส่วนนี้ทางร้านจึงยังไม่แนะนำ XS สำเร็จรูปค่ะ`;
    }
    const recommendation = ease < 0 || options.length > 1 ? `ช่วงอกเข้าเกณฑ์ไซส์ ${row.size} ค่ะ` : `แนะนำไซส์ ${row.size} ค่ะ`;
    return `${recommendation} อกเสื้อ ${row.chest} นิ้ว เหลือช่วงอก ${row.chest - chest} นิ้ว เอวเสื้อ ${row.waist} นิ้ว ${waistFit}`;
  });
  return replies.join(' ');
}
